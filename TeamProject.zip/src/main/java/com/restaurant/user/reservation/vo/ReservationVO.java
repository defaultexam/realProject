package com.restaurant.user.reservation.vo;

public class ReservationVO {

}
