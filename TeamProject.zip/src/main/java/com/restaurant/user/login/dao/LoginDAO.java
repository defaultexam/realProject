package com.restaurant.user.login.dao;

public class LoginDAO {

}
